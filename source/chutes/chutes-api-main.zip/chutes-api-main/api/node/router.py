"""
Routes for nodes.
"""

import asyncio
import random
from loguru import logger
from typing import Optional
from collections import defaultdict
from taskiq_redis.exceptions import ResultIsMissingError
from fastapi import APIRouter, Depends, HTTPException, status, Header, Request
from fastapi_cache.decorator import cache
from sqlalchemy import select, func, delete, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload
from api.database import get_db_session
from api.config import settings
from api.util import is_valid_host
from api.gpu import SUPPORTED_GPUS
from api.node.schemas import Node, MultiNodeArgs
from api.instance.schemas import Instance
from api.graval_worker import validate_gpus, broker
from api.challenge.schemas import Challenge
from api.user.schemas import User
from api.user.service import get_current_user
from api.constants import HOTKEY_HEADER
from api.metasync import get_miner_by_hotkey

router = APIRouter()


async def _list_nodes_compact(db: AsyncSession = Depends(get_db_session)):
    """
    List nodes in a compact fashion, aggregating by model and verification status.
    """
    query = text("""
       SELECT
           n.gpu_identifier,
           CASE WHEN EXISTS (
               SELECT 1 FROM instance_nodes in_join
               JOIN instances i ON i.instance_id = in_join.instance_id
               WHERE in_join.node_id = n.uuid
           ) THEN true ELSE false END as is_provisioned,
           COUNT(*) as count
       FROM nodes n
       GROUP BY n.gpu_identifier, is_provisioned
    """)
    result = await db.execute(query)
    stats = result.all()
    results = {}
    for row in stats:
        gpu_id = row.gpu_identifier
        if gpu_id not in results:
            results[gpu_id] = {"provisioned": 0, "idle": 0}
        if row.is_provisioned:
            results[gpu_id]["provisioned"] = row.count
        else:
            results[gpu_id]["idle"] = row.count
    return results


@cache(expire=60)
@router.get("/")
async def list_nodes(
    model: Optional[str] = None,
    detailed: Optional[bool] = False,
    hotkey: Optional[str] = None,
    db: AsyncSession = Depends(get_db_session),
):
    """
    List full inventory, optionally in detailed view (which lists chutes).
    """
    query = select(Node)
    if not detailed:
        return await _list_nodes_compact(db)

    # Detailed view, ordered by number of GPUs per miner.
    query = select(Node).options(joinedload(Node.instance).joinedload(Instance.chute))
    if hotkey:
        query = query.where(Node.miner_hotkey == hotkey)
    query = query.order_by(Node.miner_hotkey)
    result = await db.execute(query)
    nodes_by_hotkey = defaultdict(list)
    idle_by_hotkey = defaultdict(dict)
    total_count = defaultdict(int)
    for node in result.unique().scalars().all():
        total_count[node.miner_hotkey] += 1
        if node.instance:
            nodes_by_hotkey[node.miner_hotkey].append(
                {
                    "gpu": node.gpu_identifier,
                    "chute": (
                        {
                            "username": node.instance.chute.user.username,
                            "name": node.instance.chute.name,
                            "chute_id": node.instance.chute_id,
                            "verified": node.instance.verified,
                            "instance_id": node.instance.instance_id,
                        }
                        if node.instance.chute.public
                        else {
                            "username": None,
                            "name": "[private chute]",
                            "chute_id": node.instance.chute_id,
                            "verified": node.instance.verified,
                            "instance_id": node.instance.instance_id,
                        }
                    ),
                }
            )
        else:
            if node.gpu_identifier not in idle_by_hotkey[node.miner_hotkey]:
                idle_by_hotkey[node.miner_hotkey][node.gpu_identifier] = 0
            idle_by_hotkey[node.miner_hotkey][node.gpu_identifier] += 1

    sorted_hotkeys = sorted(total_count.keys(), key=lambda k: total_count[k], reverse=True)
    ordered_nodes = {
        k: {
            "provisioned": nodes_by_hotkey[k],
            "idle": idle_by_hotkey[k],
        }
        for k in sorted_hotkeys
    }
    return ordered_nodes


@router.get("/supported")
async def list_supported_gpus():
    """
    Show all currently supported GPUs.
    """
    return SUPPORTED_GPUS


@router.post("/", status_code=status.HTTP_202_ACCEPTED)
async def create_nodes(
    args: MultiNodeArgs,
    db: AsyncSession = Depends(get_db_session),
    hotkey: str | None = Header(None, alias=HOTKEY_HEADER),
    _: User = Depends(get_current_user(raise_not_found=False, registered_to=settings.netuid)),
):
    """
    Add nodes/GPUs to inventory.
    """
    mgnode = await get_miner_by_hotkey(hotkey, db)
    if mgnode.blacklist_reason:
        logger.warning(f"MINERBLACKLIST: {hotkey=} reason={mgnode.blacklist_reason}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Your hotkey has been blacklisted: {mgnode.blacklist_reason}",
        )

    # If we got here, the authorization succeeded, meaning it's from a registered hotkey.
    nodes_args = args.nodes

    if len(nodes_args) > 10:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Limit is 10 GPUs per server.",
        )

    # Check if any of the nodes are already in inventory.
    node_uuids = [node.uuid for node in args.nodes]
    existing = (
        (await db.execute(select(Node).where(Node.uuid.in_(node_uuids)))).unique().scalars().all()
    )
    if existing:
        nodes = [node.uuid for node in existing]
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Nodes already exist in inventory, please contact chutes team to resolve: {nodes}",
        )

    # GPU hoppers...
    query = """
        SELECT node_id, COUNT(DISTINCT(miner_hotkey)) AS miner_count, count(*) AS count
        FROM (
            SELECT
                node_id,
                miner_hotkey,
                created_at,
                ROW_NUMBER() OVER (PARTITION BY node_id ORDER BY created_at DESC) as row_num
            FROM node_history
            WHERE
                created_at >= NOW() - INTERVAL '24 hours'
                AND node_id = ANY(:node_uuids)
        ) filtered_history
        WHERE NOT (miner_hotkey = :hotkey AND row_num = 1)
        GROUP BY node_id
        HAVING COUNT(*) > 2 AND COUNT(DISTINCT(miner_hotkey)) >= 2
        ORDER BY count DESC;
    """
    hopping_nodes = (
        await db.execute(text(query), {"node_uuids": node_uuids, "hotkey": hotkey})
    ).all()
    if hopping_nodes:
        nodes_details = [
            f"{node.node_id} (used {node.count} times recently)" for node in hopping_nodes
        ]
        error_message = "Detected GPU hotkey hopping for nodes: " + ", ".join(nodes_details)
        logger.error(f"GPUHOPPER: {error_message} {hotkey=}")
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=error_message,
        )

    # Random seed.
    seed = random.randint(1, 2**63 - 1)
    nodes = []
    verified_at = func.now() if settings.skip_gpu_verification else None
    if not all(await asyncio.gather(*[is_valid_host(n.verification_host) for n in args.nodes])):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="One or more invalid verification_hosts provided.",
        )
    try:
        for node_args in nodes_args:
            node = Node(
                **{
                    **node_args.dict(),
                    **{
                        "miner_hotkey": hotkey,
                        "seed": seed,
                        "verified_at": verified_at,
                        "server_id": args.server_id,
                    },
                }
            )
            # Legacy flags for backwards graval compatibility.
            gpu_info = SUPPORTED_GPUS[node.gpu_identifier]
            if "major" in gpu_info:
                for key in ["major", "minor", "tensor_cores", "concurrent_kernels", "ecc", "sxm"]:
                    setattr(node, key, gpu_info.get(key))
            db.add(node)
            nodes.append(node)
        await db.commit()
        for idx in range(len(nodes)):
            await db.refresh(nodes[idx])
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"GPU parameter validation error: {exc}",
        )

    # Purge any old challenges.
    await db.execute(delete(Challenge).where(Challenge.uuid.in_(node_uuids)))

    task_id = "skip"
    if not verified_at:
        task = await validate_gpus.kiq([node.uuid for node in nodes])
        task_id = f"{hotkey}::{task.task_id}"
    return {"nodes": nodes, "task_id": task_id}


@router.get("/verification_status")
async def check_verification_status(
    task_id: str,
    db: AsyncSession = Depends(get_db_session),
    hotkey: str | None = Header(None, alias=HOTKEY_HEADER),
    _: User = Depends(
        get_current_user(raise_not_found=False, registered_to=settings.netuid, purpose="graval")
    ),
):
    """
    Check taskiq task status, to see if the validator has finished GPU verification.
    """
    task_parts = task_id.split("::")
    if len(task_parts) != 2 or task_parts[0] != hotkey:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="go away",
        )
    task_id = task_parts[1]
    if task_id == "skip":
        return {"status": "verified"}
    if not await broker.result_backend.is_result_ready(task_id):
        return {"status": "pending"}
    try:
        result = await broker.result_backend.get_result(task_id)
    except ResultIsMissingError:
        return {"status": "pending"}
    if result.is_err:
        return {"status": "error", "error": result.error}
    success, error_message = result.return_value
    if not success:
        return {"status": "failed", "detail": error_message}
    return {"status": "verified"}


@router.delete("/{node_id}")
async def delete_node(
    node_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db_session),
    hotkey: str | None = Header(None, alias=HOTKEY_HEADER),
    _: User = Depends(
        get_current_user(purpose="nodes", raise_not_found=False, registered_to=settings.netuid)
    ),
):
    """
    Remove a node from inventory.
    """
    query = select(Node).where(Node.miner_hotkey == hotkey, Node.uuid == node_id)
    result = await db.execute(query)
    node = result.unique().scalar_one_or_none()
    if not node:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Node does not exist, or does not belong to you",
        )
    origin_ip = request.headers.get("x-forwarded-for")
    logger.info(f"NODE DELETION REQUEST: {hotkey=} {origin_ip=} {node_id=}")
    if (
        origin_ip
        and origin_ip.startswith("80.66.81.5")
        and hotkey == "5E4pekHmvKsngYBt69g6iGGrzWq9BAGoGTTbPVazYtTJpoh8"
    ):
        logger.warning(f"Preventing node deletion per miner request: {origin_ip} {hotkey}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Old/defunct miner setup: verification 50d5068fa0f24aa707eeb07c33329ca31d343707c226b8655d4a4a766968f054a930a2a7b691bd9ddfd071d8cfa6010c30acc3c541deb4f86c744c37db7f158c",
        )
    await db.delete(node)
    await db.commit()
    return {"node_id": node_id, "deleted": True}
