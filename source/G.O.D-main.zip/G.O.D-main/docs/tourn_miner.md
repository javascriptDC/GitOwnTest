# Tournament Miner Documentation 🏆

This guide covers everything you need to know about creating and running a training repository for G.O.D (Gradient-On-Demand) tournaments.

## Overview

The tournament system builds and runs your training code in Docker containers. Your code will compete against other miners by training models on provided datasets within time and resource constraints.

## Prerequisites for Tournament Participation

To compete in tournaments, miners must meet the following requirements:

1. **Subnet Registration**: You must be registered on the G.O.D subnet (netuid 56 on mainnet, 241 on testnet)
   - Register using: `btcli s register` (mainnet) or `btcli s register --network test` (testnet)
   - Post your IP to the metagraph using fiber: `fiber-post-ip --netuid 56 --subtensor.network finney --external_port 7999 --wallet.name default --wallet.hotkey default --external_ip [YOUR-IP]`

2. **Active Miner**: Your miner must be running and listening for training repository requests
   - The miner must expose the `/training_repo/{task_type}` endpoint that returns your training repository details
   - Start your miner with: `task miner`

3. **Sufficient Stake**: You must have enough stake on your hotkey to be in the **top 32 miners by stake**
   - The tournament system selects participants based on stake rankings
   - Miners who have participated in previous tournaments receive a stake boost (5% per completed tournament, max 25%)
   - Your actual stake requirement depends on the current competition but you must be in the top 32 to be eligible
   - **Important**: Stake must be maintained throughout the entire tournament. Winners who fall below the required stake threshold will be eliminated even after winning rounds

## Tournament Registration

The miner already includes the required endpoint at `/training_repo/{task_type}` that returns:

```json
{
  "github_repo": "https://github.com/yourname/training-repo",
  "commit_hash": "abc123..."
}
```

Where `task_type` can be:
- `"text"` - For text-based tournaments (Instruct, DPO, GRPO, Chat)
- `"image"` - For image-based tournaments (SDXL, Flux)

## Docker-Based Architecture

### Recommended Base Images

**For Text Tasks (Instruct, DPO, GRPO, Chat):**
```dockerfile
FROM axolotlai/axolotl:main-py3.11-cu124-2.5.1
```

**For Image Tasks (SDXL, Flux):**
```dockerfile
FROM diagonalge/kohya_latest:latest
```

### Required Repository Structure

```
your-training-repo/
├── dockerfiles/
│   ├── standalone-text-trainer.dockerfile
│   └── standalone-image-trainer.dockerfile
```

**Important:** The dockerfile paths must be exactly:
- `dockerfiles/standalone-text-trainer.dockerfile`
- `dockerfiles/standalone-image-trainer.dockerfile`

## CLI Arguments

Your training scripts accept these standardised CLI arguments:

### Text Training Arguments
```bash
--task-id             # Unique task identifier
--model               # Base model to finetune
--dataset             # S3 dataset URL
--dataset-type        # JSON structure of dataset (columns, format)
--task-type           # "InstructTextTask", "DpoTask", or "GrpoTask"
--expected-repo-name  # Expected HuggingFace repository name for upload
--hours-to-complete   # Time limit in hours for the job to finish
```

**Note:** For GRPO tasks, the reward functions used for training can be found in [`core/manual_reward_funcs.py`](https://github.com/rayonlabs/G.O.D/blob/main/core/manual_reward_funcs.py).

### Image Training Arguments
```bash
--task-id             # Unique task identifier
--model               # Base model to finetune (e.g., stabilityai/stable-diffusion-xl-base-1.0)
--dataset-zip         # S3 URL to dataset zip file
--model-type          # "sdxl" or "flux"
--expected-repo-name  # Expected HuggingFace repository name for upload
--hours-to-complete   # Time limit in hours for the job to finish
```

## Training Logs and Monitoring

### Grafana Dashboard
View real-time training logs and metrics at: http://185.141.218.75:3001/d/training-runs/training-runs-dashboard

## WandB Logging for Your Training Analysis

Include WandB logging so you can analyze your training runs after tournaments complete:

```python
def create_config(task_id, model, dataset, dataset_type, file_format, output_dir, expected_repo_name=None, log_wandb=True):
    if log_wandb:
        config["wandb_runid"] = f"{task_id}_{expected_repo_name}"
        config["wandb_name"] = f"{task_id}_{expected_repo_name}"
        config["wandb_mode"] = "offline"  # Logs saved locally
        os.makedirs(train_cst.WANDB_LOGS_DIR, exist_ok=True)

def patch_wandb_symlinks(base_dir: str):
    """Handle WandB symlinks by converting to real files."""
    for root, _, files in os.walk(base_dir):
        for name in files:
            full_path = os.path.join(root, name)
            if os.path.islink(full_path):
                target_path = os.readlink(full_path)
                try:
                    os.unlink(full_path)
                    if os.path.exists(target_path):
                        shutil.copy(target_path, full_path)
                    else:
                        pathlib.Path(full_path).touch()
                except Exception as e:
                    print(f"Symlink patch failed: {e}")

# Call after training completes
patch_wandb_symlinks(train_cst.WANDB_LOGS_DIR)
```

## Dataset Handling

### Text Datasets
- Always provided as S3 URLs
- Format: JSON
- Dataset type parameter describes the structure (columns, format)

### Image Datasets
- Provided as S3 URLs to zip files
- Should contain images and metadata (captions)
- Your script must handle extraction and preparation

## Output Structure Requirements

**Critical:** The output paths are standardised and MUST NOT be changed. The uploader expects models at these exact locations.

For your reference, all the paths used in training can be found at:

```trainer/constants.py```

And the functions to construct the paths can be found at:

```trainer/utils/training_paths.py```

Here are some most important paths:


### Model Output Path
```python
output_dir = f"/app/checkpoints/{task_id}/{expected_repo_name}"
```

### Input Model Cache Path
```python
# Models are pre-downloaded to this location by the downloader container
model_path = f"/cache/models/{model.replace('/', '--')}"
```

### Image Dataset Path
```python
# Datasets are pre-downloaded to this location by the downloader container
model_path = f"/cache/datasets/{task_id}_tourn.zip"
```

### Text Dataset Path
```python
# Datasets are pre-downloaded to this location by the downloader container
model_path = f"/cache/datasets/{task_id}_train_data.json"
```

## Utility Functions in Trainer Scripts

### Image Trainer
```python
def get_model_path(path: str) -> str
```
Is used to get the folder/file path for image models. The image models can either be a safetensors file, or a diffusers format folder. The function resolves the path to either of those.

### Text Trainer
```python
def patch_wandb_symlinks(base_dir:str)
```
Fixes the local wandb logs that are later synced to cloud. Offline saves are prone to broken files and symlinks, causing issues while syncing. This function patches those files, which has to be done in the training context.

```python
def patch_model_metadata(output_dir: str, base_model_id: str)
```
Huggingface verifies the base model id when a finetune is uploaded. That gets broken at times due to the nature of our training with localized paths and separate uploads. This function patches the model metadata to deal with that, fixes the model name back to the original huggingface link.

## Example Entrypoint Script

Create a simple entrypoint that passes arguments to your training script:

```bash
#!/bin/bash
set -e

# For text training
python3 /workspace/scripts/text_trainer.py "$@"

# For image training
python3 /workspace/scripts/image_trainer.py "$@"
```

## Testing Your Setup

Test scripts are provided to validate your implementation locally:

```bash
# Text task examples
./examples/run_instruct_task.sh
./examples/run_dpo_task.sh
./examples/run_grpo_task.sh

# Image task examples
./examples/run_image_task.sh
```

## Tournament Structure

Tournaments run continuously with 4-7 day duration and 24-hour gaps between tournaments. There are separate tournaments for:
- **Text**: Instruct, DPO, GRPO tasks
- **Image**: SDXL and Flux diffusion tasks

### Group Stage
- Miners are organized into groups of 6-8 participants
- Each group competes on 3 tasks
- Top 1-3 performers from each group advance to knockout rounds

### Knockout Rounds
- Single elimination format
- Runs when field is reduced to less than 16 miners
- Head-to-head competition

### Boss Round
- Tournament winner must face defending champion
- Uses progressive threshold system with exponential decay based on consecutive wins
- **Tournament-Specific Winning Requirements**:
  - **Text tournaments**: Challenger wins by majority rule (2/3 or 3/3 tasks)
  - **Image tournaments**: Challenger must win ALL 3 tasks (perfect sweep) to dethrone the champion
- Defending champion retains title unless challenger meets the tournament-specific winning requirement

#### Championship Defense Thresholds
The advantage required to dethrone a champion decreases with each successful defense using an exponential decay formula:

![Championship Defense Thresholds](./images/championship_thresholds.png)

**Formula:** `threshold = max(EXPONENTIAL_MIN_THRESHOLD, EXPONENTIAL_BASE_THRESHOLD × EXPONENTIAL_DECAY_RATE^consecutive_wins)`

Where constants (defined in `validator/tournament/constants.py`):
- `EXPONENTIAL_BASE_THRESHOLD`: Starting threshold for new champions
- `EXPONENTIAL_DECAY_RATE`: Decay factor per consecutive win  
- `EXPONENTIAL_MIN_THRESHOLD`: Minimum threshold floor

This system ensures:
- New champions must prove themselves with a significant margin
- Long-reigning champions become progressively more vulnerable
- Minimum threshold prevents stagnation

### GPU Requirements
- Determined by model size and task type
- Resource limits are enforced (memory, CPU)
- Plan for efficient resource usage

## Common Pitfalls to Avoid

1. **Don't change output paths** - The uploader expects exact locations
2. **Don't hardcode paths** - Use provided constants
3. **Don't ignore time limits** - Respect the hours-to-complete parameter
4. **Don't skip validation** - Test with various model sizes and datasets
5. **Don't upload/download in the training script** - Training container is run with no access to internet or host machine

## Reference Implementation

The G.O.D repository provides base training scripts that you can customize:
- `scripts/text_trainer.py` - Base implementation for text tasks
- `scripts/image_trainer.py` - Base implementation for image tasks

These scripts handle all required functionality including dataset preparation, training configuration, and model saving. You can modify and enhance these scripts to improve performance.
