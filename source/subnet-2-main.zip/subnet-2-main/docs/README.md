[← Back to home]

<div align="center">

# Docs

</div>

## [Setup instructions]

Instructions for setting up your machine to validate or mine on the subnet.

[View setup instructions →]

## [Running on Mainnet]

Instructions for mining or validating on mainnet.

[View mainnet instructions →]

## [Running on Testnet]

Instructions for mining or validating on testnet.

[View testnet instructions →]

## [Running locally (on "staging")]

Instructions for mining or validating on a local bittensor instance, called staging.

[View local instructions →]

## [Command Line Arguments]

An overview of command line configuration options supported by miner and validator software.

[View CLI Arguments →]

## [PM2 Configuration]

Instructions for configuring a PM2 ecosystem file which allows for streamlined startup of miners and validators.

[View PM2 Configuration →]

## [Prometheus and Grafana Configuration]

Instructions for configuring Prometheus and Grafana to monitor your validator.

[View Prometheus and Grafana Configuration →]

## [Versioning]

Information about the versioning system and how to stay up-to-date with the latest releases.

[View versioning →]

## [Custom Circuit Integrations]

Instructions for how to integrate your own zero-knowledge circuits into the subnet.

[View Custom Circuit Integrations →]

[Setup instructions]: ./shared_setup_steps.md
[Running on Mainnet]: ./running_on_mainnet.md
[Running on Testnet]: ./running_on_testnet.md
[Running locally (on "staging")]: ./running_on_staging.md
[Command Line Arguments]: ./command_line_arguments.md
[PM2 Configuration]: ./pm2_configuration.md
[View setup instructions →]: ./shared_setup_steps.md
[View CLI Arguments →]: ./command_line_arguments.md
[View PM2 Configuration →]: ./pm2_configuration.md
[View mainnet instructions →]: ./running_on_mainnet.md
[View testnet instructions →]: ./running_on_testnet.md
[View local instructions →]: ./running_on_staging.md
[Prometheus and Grafana Configuration]: ./prometheus.md
[View Prometheus and Grafana Configuration →]: ./prometheus.md
[Custom Circuit Integrations]: ./custom_circuit_integrations.md
[View Custom Circuit Integrations →]: ./custom_circuit_integrations.md
[Versioning]: ./versioning.md
[View versioning →]: ./versioning.md
[← Back to home]: ../
