# model_loader.py
import os
import json
from glob import glob

import numpy as np
import torch
from train_model import SimpleUNet  # make sure this import works


class ZeusModelLoader:
    """
    Loads trained models for each variable and provides
    a simple predict() interface for the miner.
    """

    def __init__(self, models_root, context_hours=24, forecast_hours=24, device=None):
        self.models_root = models_root
        self.context_hours = context_hours
        self.forecast_hours = forecast_hours

        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        print(f"[ModelLoader] Using device: {self.device}")

        self.models = {}   # variable -> model
        self.norms = {}    # variable -> {"mean": ..., "std": ...}

        self._load_all_models()

    def _load_all_models(self):
        print(f"[ModelLoader] Scanning {self.models_root} for FINAL models...")

        # Only load exact final model files: model_<var>.pt
        final_paths = glob(os.path.join(self.models_root, "*/model_*.pt"))

        for path in final_paths:
            base = os.path.basename(path)

            # Skip epoch checkpoints like model_var_epoch3.pt
            if "_epoch" in base:
                continue

            if not base.startswith("model_") or not base.endswith(".pt"):
                continue

            # Extract variable name: model_<var>.pt → <var>
            varname = base[len("model_"):-len(".pt")]
            var_dir = os.path.dirname(path)

            print(f"[ModelLoader] Loading FINAL model for: {varname}")

            # Construct model
            model = SimpleUNet(
                in_channels=self.context_hours,
                out_channels=self.forecast_hours,
                hidden=64
            ).to(self.device)

            ckpt = torch.load(path, map_location=self.device)

            # New format (dict with "model")
            if isinstance(ckpt, dict) and "model" in ckpt:
                print("[INFO] Loading NEW checkpoint format")
                model.load_state_dict(ckpt["model"])

            # Old format (just weights)
            else:
                print("[INFO] Loading OLD checkpoint format")
                model.load_state_dict(ckpt)

            model.eval()

            # Load normalization file
            norm_path = os.path.join(var_dir, f"norm_{varname}.json")
            if not os.path.exists(norm_path):
                print(f"[WARN] Missing norm file for {varname}, skipping.")
                continue

            with open(norm_path, "r") as f:
                norms = json.load(f)

            mean = norms.get("mean")
            std = norms.get("std")

            if mean is None or std is None:
                print(f"[WARN] norm file incomplete for {varname}, skipping.")
                continue

            # Register model + norms
            self.models[varname] = model
            self.norms[varname] = {"mean": float(mean), "std": float(std)}

        print(f"[ModelLoader] Loaded {len(self.models)} FINAL models.")

    @torch.no_grad()
    def predict(self, variable: str, input_tensor: torch.Tensor) -> np.ndarray:
        """
        variable: e.g. "2m_temperature"
        input_tensor: torch.Tensor of shape [context_hours, H, W] in ERA5 units

        Returns: numpy array [forecast_hours, H, W] in ERA5 units
        """
        if variable not in self.models:
            raise ValueError(f"[ModelLoader] No model for variable '{variable}'")

        model = self.models[variable]
        norm = self.norms[variable]
        mean = norm["mean"]
        std = norm["std"]

        # normalize
        x = (input_tensor - mean) / (std + 1e-6)
        x = x.unsqueeze(0).to(self.device)  # [1, C, H, W]

        # forward
        y = model(x)[0]  # [forecast_hours, H, W]

        # de-normalize
        y = y * (std + 1e-6) + mean
        return y.cpu().numpy()
