# --------------------------------------------------------------
# Zeus Subnet 18 – Corrected Miner
# Includes: model loading, history fetch, prediction, safety rails
# --------------------------------------------------------------
import os
import sys

import time
import torch
import typing
import bittensor as bt
import numpy as np
import openmeteo_requests
import datetime

# Ensure project root (/home/ubuntu/Zeus) is on sys.path
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from zeus.data.converter import get_converter
from zeus.utils.config import get_device_str
from zeus.utils.time import to_timestamp
from zeus.protocol import TimePredictionSynapse
from zeus.base.miner import BaseMinerNeuron
from zeus import __version__ as zeus_version

from model_loader import ZeusModelLoader


class Miner(BaseMinerNeuron):
    """
    Zeus SN18 custom miner using trained ML models instead of Open-Meteo.
    """

    def __init__(self, config=None):
        super().__init__(config=config)

        self.device: torch.device = torch.device(get_device_str())
        self.openmeteo_api = openmeteo_requests.Client()

        # Load all trained UNet models
        self.model_loader = ZeusModelLoader(
            models_root="trained_models",
            context_hours=24,
            forecast_hours=24,
        )

        bt.logging.info("Miner initialized. Attaching forward/blacklist/priority.")
        self.axon.attach(
            forward_fn=self.forward,
            blacklist_fn=self.blacklist,
            priority_fn=self.priority,
        )

    # ----------------------------------------------------------
    # Forward Pass
    # ----------------------------------------------------------
    async def forward(self, synapse: TimePredictionSynapse) -> TimePredictionSynapse:

        coordinates = torch.tensor(synapse.locations)
        H, W, _ = coordinates.shape

        start_time = to_timestamp(synapse.start_time)
        end_time = to_timestamp(synapse.end_time)
        bt.logging.info(
            f"Received request! Predicting {synapse.requested_hours} hours of {synapse.variable} for grid of shape {coordinates.shape}."
        )

        # ------------------------------------------------------
        # 1. Build 48h context window
        # ------------------------------------------------------
        ctx = self.model_loader.context_hours
        history_start = start_time - datetime.timedelta(hours=ctx)
        
        converter = get_converter(synapse.variable)
        lat, lon = coordinates.view(-1, 2).T

        history_params = {
            "latitude": lat.tolist(),
            "longitude": lon.tolist(),
            "hourly": converter.om_name,
            "start_hour": history_start.isoformat(timespec="minutes"),
            "end_hour": start_time.isoformat(timespec="minutes"),
            "apikey": "ujUz0QpM4fIud4UC"
        }

        responses = self.openmeteo_api.weather_api(
            "https://customer-api.open-meteo.com/v1/forecast",
            params=history_params,
            method="POST"
        )

        # ------------------------------------------------------
        # 2. Convert OM → tensor [48, H, W]
        # ------------------------------------------------------
        raw = np.stack(
            [resp.Hourly().Variables(0).ValuesAsNumpy() for resp in responses],
            axis=0,  # [H*W, T_hist]
        )

        T_hist = raw.shape[1]
        if T_hist < ctx:
            raise RuntimeError(f"History too short ({T_hist} < {ctx})")

        raw = raw[:, -ctx:]                # [H*W, 48]
        raw = raw.reshape(H, W, ctx)
        raw = raw.transpose(2, 0, 1)       # [48, H, W]

        # Convert OM units → ERA5 units
        hist_era5 = converter.om_to_era5(torch.tensor(raw, dtype=torch.float32))
        hist_np = hist_era5.cpu().numpy()

        # ------------------------------------------------------
        # 3. Run model → [F, H, W]
        # ------------------------------------------------------
        # pred = self.model_loader.predict(
        #     synapse.variable,
        #     torch.tensor(hist_np, dtype=torch.float32),
        # )

        hist_tensor = torch.tensor(hist_np, dtype=torch.float32)

        try:
            pred = self.model_loader.predict(
                synapse.variable,
                hist_tensor,
            )
        except Exception as e:
            bt.logging.error(f"[Miner] Model prediction failed for {synapse.variable}: {e}")
            bt.logging.error("[Miner] Using simple persistence fallback.")

            # Fallback: repeat last context hour over time
            F_hours = synapse.requested_hours or self.model_loader.forecast_hours

            if hist_tensor.ndim == 3:
                # [C, H, W]
                last = hist_tensor[-1]  # [H, W]
            elif hist_tensor.ndim == 2:
                # [C, N] → reshape using grid info
                C, N = hist_tensor.shape
                if N == H * W:
                    last = hist_tensor[-1].reshape(H, W)
                elif N == H:
                    last = hist_tensor[-1].unsqueeze(-1).repeat(1, W)
                elif N == W:
                    last = hist_tensor[-1].unsqueeze(0).repeat(H, 1)
                else:
                    # absolute worst case: zeros
                    last = torch.zeros(H, W)
            else:
                last = torch.zeros(H, W)

            pred = last.unsqueeze(0).repeat(F_hours, 1, 1).cpu().numpy()


        # ------------------------------------------------------
        # 4. Safety Rails (very important)
        # ------------------------------------------------------
        output = self._sanitize_prediction(
            pred,
            H=H,
            W=W,
            requested_T=synapse.requested_hours,
        )

        synapse.predictions = output.tolist()
        synapse.version = zeus_version
        bt.logging.info(f"Output shape → {output.shape}")

        return synapse

    # ----------------------------------------------------------
    # SAFETY RAILS – strict validator-compatible output
    # ----------------------------------------------------------
    def _sanitize_prediction(self, pred, H, W, requested_T):
        """
        Ensures [T, H, W], no NaNs/Infs, valid grid shape.
        """

        # Convert torch → numpy
        if isinstance(pred, torch.Tensor):
            pred = pred.detach().cpu().numpy()

        # Remove batch dim or singleton dims
        if pred.ndim == 4 and pred.shape[0] == 1:
            pred = pred[0]
        if pred.ndim == 4 and pred.shape[-1] == 1:
            pred = pred[..., 0]

        # Must be [T, H, W] shape
        # Fix 2D → reshape if it's (T, H*W)
        if pred.ndim == 2 and pred.shape[1] == H * W:
            pred = pred.reshape(pred.shape[0], H, W)

        # Trim or pad T dimension
        cur_T = pred.shape[0]
        if cur_T > requested_T:
            pred = pred[:requested_T]
        elif cur_T < requested_T:
            last = pred[-1:]
            missing = requested_T - cur_T
            pred = np.concatenate([pred, np.repeat(last, missing, axis=0)], axis=0)

        # Fix spatial drift (common ConvTranspose2d bug)
        ph, pw = pred.shape[1], pred.shape[2]
        if ph != H or pw != W:
            # Clamp to grid
            pred = pred[:, :H, :W]
            # Pad if too small
            if pred.shape[1] < H:
                pad_h = H - pred.shape[1]
                pred = np.pad(pred, ((0, 0), (0, pad_h), (0, 0)), mode="edge")
            if pred.shape[2] < W:
                pad_w = W - pred.shape[2]
                pred = np.pad(pred, ((0, 0), (0, 0), (0, pad_w)), mode="edge")

        # Clean NaN/Inf
        pred = np.nan_to_num(pred, nan=0.0, posinf=1e5, neginf=-1e5)

        return torch.tensor(pred, dtype=torch.float32)

    # ----------------------------------------------------------
    # Standard Bittensor methods
    # ----------------------------------------------------------
    async def blacklist(self, synapse: TimePredictionSynapse) -> typing.Tuple[bool, str]:
        return await self._blacklist(synapse)
    
    async def priority(self, synapse: TimePredictionSynapse) -> float:
        return await self._priority(synapse)


# --------------------------------------------------------------
# MAIN LOOP
# --------------------------------------------------------------
if __name__ == "__main__":
    with Miner() as miner:
        while True:
            bt.logging.info(f"Miner running | uid {miner.uid} | {time.time()}")
            time.sleep(30)
