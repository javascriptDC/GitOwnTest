#!/usr/bin/env python3
"""
Train a Zeus weather model for a single ERA5 variable.

Supports:
- 4-level deep ZeusUNet (Residual + GroupNorm + SE attention)
- log1p normalization for precipitation
- AdamW optimizer with cosine annealing
- Gradient clipping
- TF32 tensor core acceleration (no AMP)
- Epoch-based resume via --start-epoch (loads epoch-1 checkpoint if exists)
"""

import argparse
import json
import os
import glob
import numpy as np
import xarray as xr

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import torch.nn.functional as F

# ---------------------------------------------
# Enable TF32 for faster tensor core operations
# ---------------------------------------------
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True

# ------------------------------------------------------------------------------------
# ERA5 VARIABLE NAME MAPPING
# ------------------------------------------------------------------------------------
ERA5_VAR_MAP = {
    "2m_temperature": "t2m",
    "2m_dewpoint_temperature": "d2m",
    "100m_u_component_of_wind": "u100",
    "100m_v_component_of_wind": "v100",
    "surface_pressure": "sp",
    "total_precipitation": "tp",
}

TIME_DIM = "valid_time"


# ======================================================================================
# Basic building blocks: Residual, Attention, Down/Up blocks
# ======================================================================================
class ResidualBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.gn1 = nn.GroupNorm(8, channels)
        self.conv2 = nn.Conv2d(channels, channels, kernel_size=3, padding=1)
        self.gn2 = nn.GroupNorm(8, channels)
        self.act = nn.SiLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        r = x
        x = self.act(self.gn1(self.conv1(x)))
        x = self.act(self.gn2(self.conv2(x)))
        return self.act(x + r)


class SEAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 8):
        super().__init__()
        hidden = max(channels // reduction, 8)
        self.fc1 = nn.Conv2d(channels, hidden, 1)
        self.fc2 = nn.Conv2d(hidden, channels, 1)
        self.act = nn.SiLU()
        self.sig = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        w = x.mean((2, 3), keepdim=True)
        w = self.act(self.fc1(w))
        w = self.sig(self.fc2(w))
        return x * w


class DownBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, 3, padding=1)
        self.norm = nn.GroupNorm(8, out_ch)
        self.act = nn.SiLU()
        self.res = ResidualBlock(out_ch)
        self.attn = SEAttention(out_ch)
        self.pool = nn.MaxPool2d(2)

    def forward(self, x: torch.Tensor):
        x = self.act(self.norm(self.conv(x)))
        x = self.res(x)
        x = self.attn(x)
        skip = x
        x = self.pool(x)
        return x, skip


class UpBlock(nn.Module):
    def __init__(self, in_ch: int, skip_ch: int, out_ch: int):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_ch, out_ch, 2, stride=2)
        self.res = ResidualBlock(out_ch + skip_ch)
        self.attn = SEAttention(out_ch + skip_ch)
        self.proj = nn.Conv2d(out_ch + skip_ch, out_ch, 1)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)

        # Robust spatial alignment: crop both tensors to the minimum size
        _, _, H, W = x.shape
        sH, sW = skip.shape[2], skip.shape[3]
        target_H = min(H, sH)
        target_W = min(W, sW)

        if H != target_H or W != target_W:
            x = x[..., :target_H, :target_W]
        if sH != target_H or sW != target_W:
            skip = skip[..., :target_H, :target_W]

        x = torch.cat([x, skip], dim=1)
        x = self.attn(self.res(x))
        x = self.proj(x)
        return x


# ======================================================================================
# 4-LEVEL RTX 4090 / H100 Optimized UNet
# ======================================================================================
class ZeusUNet(nn.Module):
    """
    4-level UNet:
      base -> 2*base -> 4*base -> 8*base, bottleneck = 16*base

    For base=64:
      64, 128, 256, 512, bottleneck=1024
    """

    def __init__(self, in_channels: int, out_channels: int, base: int = 64):
        super().__init__()

        c1 = base           # 64
        c2 = base * 2       # 128
        c3 = base * 4       # 256
        c4 = base * 8       # 512
        cb = base * 16      # 1024 bottleneck

        # Encoder
        self.enc1 = nn.Sequential(
            nn.Conv2d(in_channels, c1, 3, padding=1),
            nn.GroupNorm(8, c1),
            nn.SiLU(),
            ResidualBlock(c1),
            SEAttention(c1),
        )

        self.down1 = DownBlock(c1, c2)
        self.down2 = DownBlock(c2, c3)
        self.down3 = DownBlock(c3, c4)

        # Bottleneck
        self.bot = nn.Sequential(
            nn.Conv2d(c4, cb, 3, padding=1),
            nn.GroupNorm(8, cb),
            nn.SiLU(),
            ResidualBlock(cb),
            ResidualBlock(cb),
            SEAttention(cb),
        )

        # Decoder
        self.up3 = UpBlock(cb, c4, c4)
        self.up2 = UpBlock(c4, c3, c3)
        self.up1 = UpBlock(c3, c2, c2)
        self.up0 = UpBlock(c2, c1, c1)

        self.out_conv = nn.Conv2d(c1, out_channels, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape

        # Encoder
        x0 = self.enc1(x)
        x1, s1 = self.down1(x0)
        x2, s2 = self.down2(x1)
        x3, s3 = self.down3(x2)

        # Bottleneck
        xb = self.bot(x3)

        # Decoder
        x = self.up3(xb, s3)
        x = self.up2(x, s2)
        x = self.up1(x, s1)
        x = self.up0(x, x0)

        # Crop back to exact input size
        return self.out_conv(x)[..., :H, :W]


# ------------------------------------------------------------------------------------
# DATASET
# ------------------------------------------------------------------------------------
class Era5ForecastDataset(Dataset):
    """
    Loads ERA5 NetCDF data for a single variable using xarray,
    applies safety fixes (expver, number) and crops odd-size latitude.
    """

    def __init__(self, files, variable: str, context_hours: int, forecast_hours: int):
        self.variable = variable
        self.context = context_hours
        self.forecast = forecast_hours

        print("[INFO] Loading dataset...")
        era5_var = ERA5_VAR_MAP[variable]

        ds = xr.open_mfdataset(files, combine="by_coords", engine="h5netcdf")[era5_var]
        ds = ds.sortby(TIME_DIM)

        # ERA5 ensemble/version dims
        if "number" in ds.dims:
            ds = ds.isel(number=0)
        if "expver" in ds.dims:
            ds = ds.isel(expver=0)

        arr = ds.values.astype(np.float32)

        # Fix odd-size latitude (e.g., 721 → 720 or 361 → 360)
        # This helps with ConvTranspose / pooling alignment.
        arr = arr[:, :-1, :]

        self.values = arr
        self.T = arr.shape[0]

        print(f"[INFO] Data loaded: time={self.T}, lat={arr.shape[1]}, lon={arr.shape[2]}")

    def __len__(self) -> int:
        return self.T - self.context - self.forecast

    def __getitem__(self, idx: int):
        X = self.values[idx: idx + self.context]
        Y = self.values[idx + self.context: idx + self.context + self.forecast]
        return torch.tensor(X), torch.tensor(Y)


# ------------------------------------------------------------------------------------
# NORMALIZATION
# ------------------------------------------------------------------------------------
def normalize_for_training(variable: str, dataset_values: np.ndarray) -> dict:
    """Return normalization config depending on variable."""
    if variable == "total_precipitation":
        print("[INFO] Using log1p normalization for precipitation.")
        return {"type": "log1p"}

    mean = float(np.nanmean(dataset_values))
    std = float(np.nanstd(dataset_values) + 1e-6)
    print(f"[INFO] mean={mean:.5f}, std={std:.5f}")
    return {"type": "z", "mean": mean, "std": std}


class NormWrapper(Dataset):
    """Wraps another dataset and applies normalization per-sample."""
    def __init__(self, base: Dataset, norm: dict):
        self.base = base
        self.norm = norm

    def __len__(self) -> int:
        return len(self.base)

    def __getitem__(self, idx: int):
        X, Y = self.base[idx]

        if self.norm["type"] == "log1p":
            return torch.log1p(X), torch.log1p(Y)

        mean, std = self.norm["mean"], self.norm["std"]
        return (X - mean) / std, (Y - mean) / std


# ------------------------------------------------------------------------------------
# TRAINING (with start-epoch based resume)
# ------------------------------------------------------------------------------------
def train(
    variable: str,
    data_glob: str,
    output_dir: str,
    context_hours: int,
    forecast_hours: int,
    batch_size: int,
    epochs: int,
    lr: float,
    start_epoch: int = 1,
):
    print("[INFO] Searching ERA5 files...")
    files = sorted(glob.glob(data_glob))
    if not files:
        raise RuntimeError(f"No files match: {data_glob}")

    print(f"[INFO] Found {len(files)} files")

    # Load dataset once for stats
    tmp_ds = Era5ForecastDataset(files, variable, context_hours, forecast_hours)
    stats = normalize_for_training(variable, tmp_ds.values)

    # Save normalization config
    os.makedirs(output_dir, exist_ok=True)
    norm_path = os.path.join(output_dir, f"norm_{variable}.json")
    with open(norm_path, "w") as f:
        json.dump(stats, f)
    print(f"[INFO] Saved normalization: {norm_path}")

    # Dataset + loader
    dataset = NormWrapper(tmp_ds, stats)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=2)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("[INFO] Training on:", device)

    # Model (you can lower base to 48 or 32 if you ever hit OOM)
    model = ZeusUNet(
        in_channels=context_hours,
        out_channels=forecast_hours,
        base=64,
    ).to(device)

    # Loss
    loss_fn = nn.SmoothL1Loss() if variable == "total_precipitation" else nn.MSELoss()

    # Optimizer + scheduler
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=epochs, eta_min=lr * 0.1
    )

    # --------------------- START-EPOCH RESUME LOGIC ---------------------
    start_epoch = max(1, start_epoch)
    if start_epoch > 1:
        # we try to load checkpoint from epoch-1
        resume_epoch = start_epoch - 1
        ckpt_path = os.path.join(output_dir, f"{variable}_epoch{resume_epoch}.pt")

        if os.path.exists(ckpt_path):
            print(f"[INFO] Resuming from epoch {start_epoch} using checkpoint: {ckpt_path}")
            ckpt = torch.load(ckpt_path, map_location=device)

            if isinstance(ckpt, dict) and "model" in ckpt:
                model.load_state_dict(ckpt["model"])
                if "optimizer" in ckpt:
                    optimizer.load_state_dict(ckpt["optimizer"])
                if "scheduler" in ckpt:
                    scheduler.load_state_dict(ckpt["scheduler"])
                print("[INFO] Loaded model + optimizer + scheduler state.")
            else:
                # backward compat: pure state_dict
                model.load_state_dict(ckpt)
                print("[WARN] Checkpoint had no optimizer/scheduler (only model).")
        else:
            print(f"[WARN] start-epoch={start_epoch} but checkpoint not found: {ckpt_path}")
            print("[WARN] Training will continue from scratch with this start_epoch value.")

    else:
        print("[INFO] Starting from epoch 1 (no checkpoint resume).")

    # --------------------- TRAIN LOOP ---------------------
    end_epoch = start_epoch + epochs - 1
    for ep in range(start_epoch, end_epoch):
        model.train()
        losses = []

        for X, Y in tqdm(loader, desc=f"Epoch {ep}/{end_epoch}"):
            X, Y = X.to(device), Y.to(device)

            optimizer.zero_grad()

            pred = model(X)

            # Main loss (high resolution)
            loss_main = loss_fn(pred, Y)

            # Multi-scale loss (downsampled by factor 2)
            loss_small = loss_fn(
                F.avg_pool2d(pred, 2),
                F.avg_pool2d(Y, 2)
            )

            # Combined multi-scale objective
            loss = 0.7 * loss_main + 0.3 * loss_small

            # Backprop + grad clipping + step
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

            losses.append(loss.item())

        scheduler.step()
        avg_loss = sum(losses) / len(losses)
        print(f"[Epoch {ep}] loss={avg_loss:.6f}")

        # Save epoch checkpoint (resume-friendly)
        ckpt = {
            "epoch": ep,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
        }
        ckpt_path = os.path.join(output_dir, f"{variable}_epoch{ep}.pt")
        torch.save(ckpt, ckpt_path)
        print(f"[INFO] Saved checkpoint: {ckpt_path}")

    # Final model (weights only)
    final_path = os.path.join(output_dir, f"{variable}.pt")
    torch.save(model.state_dict(), final_path)
    print("[OK] Final model saved:", final_path)


# ------------------------------------------------------------------------------------
# CLI
# ------------------------------------------------------------------------------------
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--variable", required=True)
    ap.add_argument("--data-glob", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--context-hours", type=int, default=24)
    ap.add_argument("--forecast-hours", type=int, default=24)
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument("--epochs", type=int, default=5)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument(
        "--start-epoch",
        type=int,
        default=1,
        help="Epoch number to start from (>=1). If >1, "
             "will try to load checkpoint for epoch-1.",
    )

    args = ap.parse_args()

    train(
        variable=args.variable,
        data_glob=args.data_glob,
        output_dir=args.output_dir,
        context_hours=args.context_hours,
        forecast_hours=args.forecast_hours,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        start_epoch=args.start_epoch,
    )
