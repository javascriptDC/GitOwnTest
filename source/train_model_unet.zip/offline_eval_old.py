#!/usr/bin/env python
import argparse
import datetime as dt
import math
import os
import random

import numpy as np
import torch
import xarray as xr
import openmeteo_requests

from model_loader import ZeusModelLoader
from zeus.data.converter import get_converter

# --- Constants matching Zeus validator behaviour (simplified) ---
ERA5_VAR_MAP = {
    "2m_temperature": "t2m",
    "2m_dewpoint_temperature": "d2m",
    "10m_u_component_of_wind": "u10",
    "10m_v_component_of_wind": "v10",
    "100m_u_component_of_wind": "u100",
    "100m_v_component_of_wind": "v100",
    "surface_pressure": "sp",
    "total_precipitation": "tp",
}
TIME_DIM = "valid_time"

MIN_RELATIVE_SCORE = -1.0
MAX_RELATIVE_SCORE = 0.8
REWARD_RMSE_WEIGHT = 0.8   # accuracy weight (we ignore efficiency offline)
EPS = 1e-6


def load_era5_tile(nc_path: str, variable: str, crop_lat: bool = True):
    """
    Load one ERA5 NetCDF variable and return numpy array [T, H, W] + time/lat/lon.
    """
    era5_name = ERA5_VAR_MAP[variable]
    ds = xr.open_dataset(nc_path)[era5_name]

    # Ensure sorted by time and drop unused dims
    ds = ds.sortby(TIME_DIM)
    if "number" in ds.dims:
        ds = ds.isel(number=0)
    if "expver" in ds.dims:
        ds = ds.isel(expver=0)

    vals = ds.values.astype(np.float32)  # [T, lat, lon]
    if crop_lat:
        vals = vals[:, :-1, :]  # 721 → 720, matches training

    times = ds[TIME_DIM].values
    lats = ds["latitude"].values
    lons = ds["longitude"].values
    if crop_lat:
        lats = lats[:-1]

    return vals, times, lats, lons


def sample_patch(data, times, lats, lons, context_hours=48, forecast_hours=24,
                 min_patch=8, max_patch=16):
    """
    Pick a random time index and a random spatial window.
    Returns:
      context [C,H,W], target [F,H,W], time_start, (lat_indices, lon_indices)
    """
    T, H, W = data.shape
    total_needed = context_hours + forecast_hours

    # choose center time so we have enough ctx+forecast around
    start_idx = random.randint(context_hours, T - forecast_hours - 1)
    ctx_start = start_idx - context_hours
    ctx_end = start_idx
    tgt_start = start_idx
    tgt_end = start_idx + forecast_hours

    # random patch
    patch_h = random.randint(min_patch, max_patch)
    patch_w = random.randint(min_patch, max_patch)
    max_i = H - patch_h
    max_j = W - patch_w
    i0 = random.randint(0, max_i)
    j0 = random.randint(0, max_j)
    i1 = i0 + patch_h
    j1 = j0 + patch_w

    context = data[ctx_start:ctx_end, i0:i1, j0:j1]   # [C, h, w]
    target = data[tgt_start:tgt_end, i0:i1, j0:j1]    # [F, h, w]

    time_start = times[tgt_start]  # first forecast time
    sub_lats = lats[i0:i1]
    sub_lons = lons[j0:j1]

    return context, target, time_start, sub_lats, sub_lons


def rmse(a, b):
    return float(np.sqrt(np.mean((a - b) ** 2)))


def mae(a, b):
    return float(np.mean(np.abs(a - b)))


def compute_improvement(model_rmse, baseline_rmse):
    return (baseline_rmse - model_rmse + EPS) / (baseline_rmse + EPS)


def curved_score(value, min_score=MIN_RELATIVE_SCORE, max_score=MAX_RELATIVE_SCORE, gamma=1.0):
    """
    Same idea as validator's get_curved_scores but just for a single score.
    """
    capped = max(min(value, max_score), min_score)
    if max_score == min_score:
        return 0.0
    norm = (capped - min_score) / (max_score - min_score)
    if norm < 0:
        norm = 0.0
    if norm > 1:
        norm = 1.0
    return float(norm ** gamma)


def call_openmeteo_baseline(variable, times_start, forecast_hours, lats, lons):
    """
    Call Open-Meteo for baseline forecast on same patch and horizon.
    Returns [F, H, W] in ERA5 units.
    """
    client = openmeteo_requests.Client()
    converter = get_converter(variable)

    # OM API expects single start & end times; we build ISO strings.
    start_dt = np.datetime_as_string(times_start, unit="m")
    start_dt = dt.datetime.fromisoformat(start_dt)
    end_dt = start_dt + dt.timedelta(hours=forecast_hours)

    # Meshgrid to match patch
    # But OM takes lists of (lat,lon), so flatten
    lat_grid, lon_grid = np.meshgrid(lats, lons, indexing="ij")
    lat_flat = lat_grid.reshape(-1)
    lon_flat = lon_grid.reshape(-1)

    params = {
        "latitude": lat_flat.tolist(),
        "longitude": lon_flat.tolist(),
        "hourly": converter.om_name,
        "start_hour": start_dt.isoformat(timespec="minutes"),
        "end_hour": end_dt.isoformat(timespec="minutes"),
    }

    resps = client.weather_api(
        "https://api.open-meteo.com/v1/forecast",
        params=params,
        method="POST",
    )

    # each resp: hourly values [F]
    vals = np.stack(
        [r.Hourly().Variables(0).ValuesAsNumpy() for r in resps],
        axis=0,  # [H*W, F]
    )

    F = vals.shape[1]
    H = len(lats)
    W = len(lons)
    vals = vals.reshape(H, W, F).transpose(2, 0, 1)  # [F,H,W]

    # convert units OM → ERA5
    vals_era = converter.om_to_era5(torch.tensor(vals, dtype=torch.float32)).numpy()
    return vals_era


def evaluate_once(
    variable: str,
    era5_file: str,
    model_root: str,
    model_epoch: int,
    context_hours: int = 48,
    forecast_hours: int = 24,
):
    # 1) load ERA5 tile
    data, times, lats, lons = load_era5_tile(era5_file, variable)

    # 2) sample patch
    ctx, tgt, t0, sub_lats, sub_lons = sample_patch(
        data, times, lats, lons,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
    )  # ctx:[C,h,w], tgt:[F,h,w]

    C, h, w = ctx.shape
    F = forecast_hours

    # 3) load model through ZeusModelLoader
    loader = ZeusModelLoader(
        models_root=model_root,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
    )

    if variable not in loader.models:
        raise RuntimeError(f"No model loaded for variable {variable}")

    # 4) run model
    ctx_tensor = torch.tensor(ctx, dtype=torch.float32)
    pred = loader.predict(variable, ctx_tensor)  # [F, h, w]

    # 5) baseline: Open-Meteo
    baseline = call_openmeteo_baseline(variable, t0, F, sub_lats, sub_lons)

    # 6) metrics
    model_rmse = rmse(pred, tgt)
    model_mae = mae(pred, tgt)
    baseline_rmse = rmse(baseline, tgt)
    baseline_mae = mae(baseline, tgt)

    # persistence baseline (last context frame)
    persistence = np.repeat(ctx[-1:], F, axis=0)
    persistence_rmse = rmse(persistence, tgt)

    improvement = compute_improvement(model_rmse, baseline_rmse)
    quality_score = curved_score(improvement, gamma=1.0)

    return {
        "variable": variable,
        "grid": (h, w),
        "model_rmse": model_rmse,
        "model_mae": model_mae,
        "baseline_rmse": baseline_rmse,
        "baseline_mae": baseline_mae,
        "persistence_rmse": persistence_rmse,
        "relative_improvement": improvement,
        "quality_score": quality_score,
    }


def main():
    parser = argparse.ArgumentParser(description="Offline Zeus SN18 evaluation")
    parser.add_argument("--variable", required=True,
                        help="e.g. 2m_temperature")
    parser.add_argument("--era5-file", required=True,
                        help="Path to ERA5 nc file, e.g. era5_data/era5_2025_10_2m_temperature.nc")
    parser.add_argument("--model-root", default="trained_models/t2m",
                        help="Dir containing model_*.pt and norm_*.json")
    parser.add_argument("--epochs", type=int, default=1,
                        help="How many random patches to evaluate")
    parser.add_argument("--context-hours", type=int, default=48)
    parser.add_argument("--forecast-hours", type=int, default=24)
    args = parser.parse_args()

    all_metrics = []
    for i in range(args.epochs):
        m = evaluate_once(
            variable=args.variable,
            era5_file=args.era5_file,
            model_root=args.model_root,
            model_epoch=0,
            context_hours=args.context_hours,
            forecast_hours=args.forecast_hours,
        )
        all_metrics.append(m)
        print(f"[Run {i+1}]")
        for k, v in m.items():
            if isinstance(v, float):
                print(f"  {k:22s}: {v:.6f}")
            else:
                print(f"  {k:22s}: {v}")
        print()

    # average over runs
    if len(all_metrics) > 1:
        print("=== AVERAGE OVER RUNS ===")
        keys = ["model_rmse", "baseline_rmse", "persistence_rmse",
                "model_mae", "baseline_mae",
                "relative_improvement", "quality_score"]
        for k in keys:
            vals = [m[k] for m in all_metrics]
            print(f"{k:22s}: {np.mean(vals):.6f}")


if __name__ == "__main__":
    main()
