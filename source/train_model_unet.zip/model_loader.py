# model_loader.py
import os
import json
from glob import glob
from typing import Dict, Any

import numpy as np
import torch
import torch.nn.functional as F

# IMPORTANT: import the same model class you used for training
from train_model_unet import ZeusUNet  # make sure this file is in the same folder


class ZeusModelLoader:
    """
    Loads trained models for each variable and provides
    a simple predict() interface for the miner.

    Expects per-variable directories like:

        trained_models/2m_temperature/2m_temperature.pt
        trained_models/2m_temperature/norm_2m_temperature.json

    or old-style:

        trained_models/t2m/model_2m_temperature.pt
        trained_models/t2m/norm_2m_temperature.json
    """

    def __init__(
        self,
        models_root: str,
        context_hours: int = 24,
        forecast_hours: int = 24,
        base_channels: int = 64,
        device: str | None = None,
    ):
        self.models_root = models_root
        self.context_hours = context_hours
        self.forecast_hours = forecast_hours
        self.base_channels = base_channels

        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        print(f"[ModelLoader] Using device: {self.device}")

        self.models: Dict[str, torch.nn.Module] = {}  # variable -> model
        self.norms: Dict[str, Dict[str, Any]] = {}    # variable -> norm dict

        self._load_all_models()

    def _load_all_models(self):
        print(f"[ModelLoader] Scanning {self.models_root} for models...")

        # find all .pt files under subdirs
        pattern = os.path.join(self.models_root, "*", "*.pt")
        all_pt_files = glob(pattern)

        # Map varname -> chosen .pt (prefer final file over epoch checkpoints)
        best_files: Dict[str, str] = {}

        for path in all_pt_files:
            base = os.path.basename(path)
            if "_epoch" in base:
                # ignore training checkpoints
                continue

            # support both "model_<var>.pt" and "<var>.pt"
            if base.startswith("model_") and base.endswith(".pt"):
                varname = base[len("model_"):-3]
            elif base.endswith(".pt"):
                varname = base[:-3]
            else:
                continue

            best_files[varname] = path

        if not best_files:
            print("[ModelLoader] No model .pt files found. Check your models_root path.")
            return

        for varname, path in best_files.items():
            var_dir = os.path.dirname(path)
            print(f"[ModelLoader] Loading model for variable: {varname} from {path}")

            # Build model with correct channel dims, same as training
            model = ZeusUNet(
                in_channels=self.context_hours,
                out_channels=self.forecast_hours,
                base=64,  # use same base as in train_model_unet.py
            ).to(self.device)

            state = torch.load(path, map_location=self.device)

            # If file is a checkpoint dict, extract "model" subkey
            if isinstance(state, dict) and "model" in state:
                state = state["model"]

            model.load_state_dict(state)
            model.eval()

            # Load normalization config
            norm_path = os.path.join(var_dir, f"norm_{varname}.json")
            if not os.path.exists(norm_path):
                print(f"[WARN] Missing norm file for {varname}, skipping.")
                continue

            with open(norm_path, "r") as f:
                norms = json.load(f)

            # Basic sanity
            if "type" not in norms:
                print(f"[WARN] norm file for {varname} missing 'type', skipping.")
                continue

            self.models[varname] = model
            self.norms[varname] = norms
            print(f"[ModelLoader] Loaded variable {varname} with norm: {norms}")

        print(f"[ModelLoader] Loaded {len(self.models)} variables total.")

    @torch.no_grad()
    def predict(self, variable: str, input_tensor: torch.Tensor) -> np.ndarray:
        """
        variable: e.g. "2m_temperature"
        input_tensor: [C, H, W] in ERA5 units (C = context_hours)

        Returns: [forecast_hours, H, W] in ERA5 units
        """
        if variable not in self.models:
            raise ValueError(f"[ModelLoader] No model for variable '{variable}'")

        model = self.models[variable]
        norm  = self.norms[variable]

        # Original size
        if input_tensor.ndim != 3:
            raise ValueError(f"[ModelLoader] Expected [C,H,W], got {input_tensor.shape}")

        C, H, W = input_tensor.shape

        # -----------------
        # Helper: fallback
        # -----------------
        def fallback_baseline() -> np.ndarray:
            # simple persistence: repeat last context hour
            last = input_tensor[-1]            # [H, W]
            out  = last.unsqueeze(0).repeat(self.forecast_hours, 1, 1)
            return out.cpu().numpy() if isinstance(out, torch.Tensor) else out.numpy()

        # -----------------
        # Main model path
        # -----------------
        try:
            x = input_tensor.clone()

            # 1) Normalize
            if norm.get("type") == "log1p":
                # precip: log1p normalisation
                x = torch.log1p(torch.clamp(x, min=0.0))
            else:
                mean = norm["mean"]
                std  = norm["std"] + 1e-6
                x = (x - mean) / std

            # [1, C, H, W]
            x = x.unsqueeze(0).to(self.device)

            # 2) Pad to safe multiple-of-16 size
            MIN_SIZE = 16
            MULT     = 16

            _, _, h, w = x.shape

            def round_up(v, m):
                return ((v + m - 1) // m) * m

            target_h = max(h, MIN_SIZE)
            target_w = max(w, MIN_SIZE)
            target_h = round_up(target_h, MULT)
            target_w = round_up(target_w, MULT)

            pad_h = target_h - h
            pad_w = target_w - w

            if pad_h > 0 or pad_w > 0:
                # pad format: (left, right, top, bottom)
                x = F.pad(x, (0, pad_w, 0, pad_h), mode="replicate")

            # 3) Forward through model
            y = model(x)     # [1, F, H_pad, W_pad]
            y = y[0]         # [F, H_pad, W_pad]

            # Crop back to original size
            y = y[:, :H, :W]  # [F, H, W]

            # 4) De-normalize
            if norm.get("type") == "log1p":
                y = torch.expm1(y)
            else:
                mean = norm["mean"]
                std  = norm["std"] + 1e-6
                y = y * std + mean

            return y.detach().cpu().numpy()

        except RuntimeError as e:
            # Last-resort safety: never crash the miner
            print(f"[ModelLoader] WARNING: model forward failed for {variable}: {e}")
            print("[ModelLoader] Using baseline persistence fallback.")
            return fallback_baseline()
