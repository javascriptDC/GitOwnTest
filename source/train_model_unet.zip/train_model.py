#!/usr/bin/env python3
import argparse
import json
import os
import glob
import numpy as np
import xarray as xr
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm


# -------------------------------
# ERA5 variable mappings
# -------------------------------
ERA5_VAR_MAP = {
    "2m_temperature": "t2m",
    "2m_dewpoint_temperature": "d2m",
    "100m_u_component_of_wind": "u100",
    "100m_v_component_of_wind": "v100",
    "surface_pressure": "sp",
    "total_precipitation": "tp",
}


TIME_DIM = "valid_time"


# -------------------------------
# Simple UNet-like CNN
# -------------------------------
class SimpleUNet(nn.Module):
    def __init__(self, in_channels, out_channels=24, hidden=64):
        super().__init__()

        self.enc1 = nn.Sequential(
            nn.Conv2d(in_channels, hidden, 3, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden, hidden, 3, padding=1),
            nn.ReLU(),
        )
        self.enc2 = nn.Sequential(
            nn.Conv2d(hidden, hidden * 2, 3, padding=1, stride=2),
            nn.ReLU(),
            nn.Conv2d(hidden * 2, hidden * 2, 3, padding=1),
            nn.ReLU(),
        )

        self.bottleneck = nn.Sequential(
            nn.Conv2d(hidden * 2, hidden * 2, 3, padding=1),
            nn.ReLU()
        )

        self.dec1 = nn.Sequential(
            nn.ConvTranspose2d(hidden * 2, hidden, 2, stride=2),
            nn.ReLU(),
            nn.Conv2d(hidden, hidden, 3, padding=1),
            nn.ReLU(),
        )

        self.final = nn.Conv2d(hidden, out_channels, 1)

    def forward(self, x):
        B, C, H, W = x.shape
        e1 = self.enc1(x)
        e2 = self.enc2(e1)
        b = self.bottleneck(e2)
        d1 = self.dec1(b)
        out = self.final(d1)

        # Fix shape to match original dimensions
        return out[..., :H, :W]


# -------------------------------
# ERA5 Dataset
# -------------------------------
class Era5ForecastDataset(Dataset):
    def __init__(self, files, variable, context_hours, forecast_hours):
        self.variable = variable
        self.context = context_hours
        self.forecast = forecast_hours

        print("[INFO] Loading dataset...")
        era5_var = ERA5_VAR_MAP[variable]

        self.ds = xr.open_mfdataset(
            files,
            combine="by_coords",
            engine="h5netcdf"
        )[era5_var]

        # Fix time dim
        self.ds = self.ds.sortby(TIME_DIM)

        # Remove ensemble/version
        if "number" in self.ds.dims:
            self.ds = self.ds.isel(number=0)
        if "expver" in self.ds.dims:
            self.ds = self.ds.isel(expver=0)

        # Convert to numpy
        self.values = self.ds.values.astype(np.float32)

        # Fix latitude size mismatch (721 → 720)
        self.values = self.values[:, :-1, :]

        self.T = self.values.shape[0]
        print(f"[INFO] Data loaded: time={self.T}, lat={self.values.shape[1]}, lon={self.values.shape[2]}")

    def __len__(self):
        return self.T - self.context - self.forecast

    def __getitem__(self, idx):
        X = self.values[idx: idx + self.context]
        Y = self.values[idx + self.context: idx + self.context + self.forecast]
        return torch.tensor(X), torch.tensor(Y)


# -------------------------------
# Training function (supports resume)
# -------------------------------
def train(variable, data_glob, output_dir,
          context_hours, forecast_hours,
          batch_size, epochs, lr, hidden,
          resume=None, start_epoch_override=None):

    print("[INFO] Finding ERA5 files...")
    files = sorted(glob.glob(data_glob))
    if not files:
        raise RuntimeError(f"No files found for: {data_glob}")
    print(f"[INFO] Using {len(files)} files for variable {variable}")

    # Dataset
    dataset = Era5ForecastDataset(
        files=files,
        variable=variable,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
    )

    # Normalization
    print("[INFO] Computing mean/std...")
    mean = float(np.nanmean(dataset.values))
    std = float(np.nanstd(dataset.values) + 1e-6)

    os.makedirs(output_dir, exist_ok=True)
    norm_path = os.path.join(output_dir, f"norm_{variable}.json")
    with open(norm_path, "w") as f:
        json.dump({"mean": mean, "std": std}, f)

    print(f"[OK] Saved normalization: {norm_path}")

    # Wrapper to normalize batches
    class NormWrapper(Dataset):
        def __init__(self, base): self.base = base
        def __len__(self): return len(self.base)
        def __getitem__(self, idx):
            X, Y = self.base[idx]
            return ( (X - mean) / std, (Y - mean) / std )

    loader = DataLoader(NormWrapper(dataset), batch_size=batch_size, shuffle=True)

    # Device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] Training on: {device}")

    # Model
    model = SimpleUNet(
        in_channels=context_hours,
        out_channels=forecast_hours,
        hidden=hidden
    ).to(device)

    optim = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    # -------------------------------
    # Resume logic
    # -------------------------------
    start_epoch = start_epoch_override

    if start_epoch > 1:
        # Example: start_epoch = 4 → load epoch 3
        prev_epoch = start_epoch - 1
        resume_path = os.path.join(
            output_dir,
            f"model_{variable}_epoch{prev_epoch}.pt"
        )

        if not os.path.exists(resume_path):
            raise RuntimeError(f"Checkpoint not found: {resume_path}")

        print(f"[INFO] Loading checkpoint: {resume_path}")
        ckpt = torch.load(resume_path, map_location=device)

        if isinstance(ckpt, dict) and "model" in ckpt:
            print("[INFO] Resuming from NEW checkpoint format")
            model.load_state_dict(ckpt["model"])
            optim.load_state_dict(ckpt["optim"])
        else:
            print("[INFO] Resuming from OLD checkpoint format (weights only)")
            model.load_state_dict(ckpt)

    print(f"[INFO] Starting training from epoch: {start_epoch}")


    # -------------------------------
    # Training loop
    # -------------------------------
    for ep in range(start_epoch, start_epoch + epochs):
        model.train()
        losses = []

        for X, Y in loader:
            X, Y = X.to(device), Y.to(device)

            pred = model(X)
            loss = loss_fn(pred, Y)

            optim.zero_grad()
            loss.backward()
            optim.step()

            losses.append(loss.item())

        avg = sum(losses) / len(losses)
        print(f"[Epoch {ep}] loss={avg:.6f}")

        # Save checkpoint
        ckpt_path = os.path.join(output_dir, f"model_{variable}_epoch{ep}.pt")
        torch.save({
            "epoch": ep,
            "model": model.state_dict(),
            "optim": optim.state_dict(),
        }, ckpt_path)

    # Final model
    final_path = os.path.join(output_dir, f"model_{variable}.pt")
    torch.save({
        "epoch": ep,
        "model": model.state_dict(),
        "optim": optim.state_dict(),
    }, final_path)
    print(f"[OK] Final model saved: {final_path}")


# -------------------------------
# CLI
# -------------------------------
if __name__ == "__main__":
    p = argparse.ArgumentParser()

    p.add_argument("--variable", required=True)
    p.add_argument("--data-glob", required=True, help="Pattern like 'era5_data/era5_*_2m_temperature.nc'")
    p.add_argument("--output-dir", required=True)

    p.add_argument("--context-hours", type=int, default=24)
    p.add_argument("--forecast-hours", type=int, default=24)

    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--hidden", type=int, default=64)

    p.add_argument("--start-epoch", type=int, default=1,
                   help="Start epoch override for OLD checkpoints")

    args = p.parse_args()

    train(
        variable=args.variable,
        data_glob=args.data_glob,
        output_dir=args.output_dir,
        context_hours=args.context_hours,
        forecast_hours=args.forecast_hours,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        hidden=args.hidden,
        start_epoch_override=args.start_epoch,
    )
