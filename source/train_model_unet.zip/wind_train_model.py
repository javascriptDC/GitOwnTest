#!/usr/bin/env python3
import argparse
import json
import os
import glob
import numpy as np
import xarray as xr
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from train_model import SimpleUNet   # your existing UNet


# ERA5 variable mappings
ERA5_WIND_VARS = {
    "100m_u_component_of_wind": "u100",
    "100m_v_component_of_wind": "v100",
}

TIME_DIM = "valid_time"


# -------------------------------
# Patch-based Wind Dataset
# -------------------------------
class WindPatchDataset(Dataset):
    def __init__(self, files, variable, context_hours, forecast_hours, patch_size=32):
        self.variable = variable
        self.context = context_hours
        self.forecast = forecast_hours
        self.patch = patch_size

        print("[INFO] Loading ERA5 wind dataset...")
        era5_var = ERA5_WIND_VARS[variable]

        ds = xr.open_mfdataset(files, combine="by_coords", engine="h5netcdf")[era5_var]
        ds = ds.sortby(TIME_DIM)

        if "number" in ds.dims:
            ds = ds.isel(number=0)
        if "expver" in ds.dims:
            ds = ds.isel(expver=0)

        arr = ds.values.astype(np.float32)
        arr = arr[:, :-1, :]  # crop 721 → 720

        self.values = arr
        self.T, self.H, self.W = arr.shape

        print(f"[INFO] Wind data: time={self.T}, H={self.H}, W={self.W}")

    def __len__(self):
        return self.T - self.context - self.forecast

    def __getitem__(self, idx):
        Xfull = self.values[idx : idx + self.context]        # [C, H, W]
        Yfull = self.values[idx + self.context : idx + self.context + self.forecast]

        # Random patch sampling
        h0 = np.random.randint(0, self.H - self.patch)
        w0 = np.random.randint(0, self.W - self.patch)

        X = Xfull[:, h0:h0+self.patch, w0:w0+self.patch]
        Y = Yfull[:, h0:h0+self.patch, w0:w0+self.patch]

        return torch.tensor(X), torch.tensor(Y)


# -------------------------------
# Training function
# -------------------------------
def train(variable, data_glob, output_dir, context_hours, forecast_hours,
          batch_size, epochs, lr, hidden, patch_size, start_epoch):

    print("[INFO] Finding ERA5 files...")
    files = sorted(glob.glob(data_glob))
    if not files:
        raise RuntimeError(f"No files found: {data_glob}")

    print(f"[INFO] Using {len(files)} files for variable {variable}")

    # Dataset
    dataset = WindPatchDataset(
        files=files,
        variable=variable,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
        patch_size=patch_size
    )

    # Compute normalization (global)
    print("[INFO] Computing global mean/std...")
    mean = float(np.nanmean(dataset.values))
    std = float(np.nanstd(dataset.values) + 1e-6)

    os.makedirs(output_dir, exist_ok=True)
    norm_path = os.path.join(output_dir, f"norm_{variable}.json")
    with open(norm_path, "w") as f:
        json.dump({"mean": mean, "std": std}, f)

    print(f"[OK] Saved normalization: {norm_path}")

    # Normalized wrapper
    class NormWrap(Dataset):
        def __init__(self, base):
            self.base = base

        def __len__(self):
            return len(self.base)

        def __getitem__(self, i):
            X, Y = self.base[i]
            return ( (X - mean) / std, (Y - mean) / std )

    loader = DataLoader(NormWrap(dataset), batch_size=batch_size, shuffle=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] Training on: {device}")

    model = SimpleUNet(
        in_channels=context_hours,
        out_channels=forecast_hours,
        hidden=hidden
    ).to(device)

    optim = torch.optim.Adam(model.parameters(), lr=lr)
    loss_fn = nn.MSELoss()

    # Resume logic
    if start_epoch > 1:
        prev = start_epoch - 1
        ckpt_path = os.path.join(output_dir, f"model_{variable}_epoch{prev}.pt")
        print(f"[INFO] Loading checkpoint: {ckpt_path}")
        ckpt = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(ckpt["model"])
        optim.load_state_dict(ckpt["optim"])

    print(f"[INFO] Starting at epoch {start_epoch}")

    # Training loop
    for ep in range(start_epoch, start_epoch + epochs):
        model.train()
        losses = []

        for X, Y in loader:
            X, Y = X.to(device), Y.to(device)
            pred = model(X)
            loss = loss_fn(pred, Y)

            optim.zero_grad()
            loss.backward()
            optim.step()

            losses.append(loss.item())

        avg = sum(losses) / len(losses)
        print(f"[Epoch {ep}] loss={avg:.6f}")

        # save checkpoint
        torch.save({
            "epoch": ep,
            "model": model.state_dict(),
            "optim": optim.state_dict(),
        }, os.path.join(output_dir, f"model_{variable}_epoch{ep}.pt"))

    # save final
    torch.save({
        "epoch": ep,
        "model": model.state_dict(),
        "optim": optim.state_dict(),
    }, os.path.join(output_dir, f"model_{variable}.pt"))

    print(f"[OK] Final model saved for {variable}")


# -------------------------------
# CLI
# -------------------------------
if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--variable", required=True)
    p.add_argument("--data-glob", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--context-hours", type=int, default=24)
    p.add_argument("--forecast-hours", type=int, default=24)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--hidden", type=int, default=64)
    p.add_argument("--patch-size", type=int, default=32)
    p.add_argument("--start-epoch", type=int, default=1)

    args = p.parse_args()

    train(
        variable=args.variable,
        data_glob=args.data_glob,
        output_dir=args.output-dir,
        context_hours=args.context_hours,
        forecast_hours=args.forecast_hours,
        batch_size=args.batch_size,
        epochs=args.epochs,
        lr=args.lr,
        hidden=args.hidden,
        patch_size=args.patch_size,
        start_epoch=args.start_epoch,
    )
