#!/usr/bin/env python3
"""
offline_eval.py

Offline evaluation for Zeus weather models.

- Loads trained model (ZeusUNet) for a single variable
- Loads ERA5 NetCDF files
- Uses SAME normalization as training (z-score or log1p)
- Computes RMSE / MAE / bias over the dataset

Example:

python offline_eval.py \
  --variable total_precipitation \
  --data-glob "era5_data/*_total_precipitation.nc" \
  --model-dir trained_models/precip \
  --context-hours 24 \
  --forecast-hours 24 \
  --batch-size 2 \
  --max-batches 200
"""

import argparse
import glob
import json
import os
from typing import Dict, Tuple, Optional

import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

# Reuse your training code
from train_model_unet import (
    ZeusUNet,
    Era5ForecastDataset,
    ERA5_VAR_MAP,
)


def load_model_and_norm(
    variable: str,
    model_dir: str,
    context_hours: int,
    forecast_hours: int,
    device: torch.device,
) -> Tuple[torch.nn.Module, Dict]:
    """
    Load model + norm config from model_dir.
    Supports:
      - model_<var>.pt
      - <var>.pt
      - checkpoints with {'model': state_dict}
    """

    # Find model file
    candidate1 = os.path.join(model_dir, f"model_{variable}.pt")
    candidate2 = os.path.join(model_dir, f"{variable}.pt")

    if os.path.exists(candidate1):
        model_path = candidate1
    elif os.path.exists(candidate2):
        model_path = candidate2
    else:
        raise FileNotFoundError(
            f"No model file found in {model_dir}. "
            f"Tried: {candidate1}, {candidate2}"
        )

    print(f"[Eval] Loading model from: {model_path}")

    # Build model with same channel dims as training
    model = ZeusUNet(
        in_channels=context_hours,
        out_channels=forecast_hours,
        base=64,  # must match train_model_unet.py
    ).to(device)

    state = torch.load(model_path, map_location=device)

    # If checkpoint dict: extract "model" key
    if isinstance(state, dict) and "model" in state:
        state = state["model"]

    model.load_state_dict(state)
    model.eval()

    # Load norm file
    norm_path = os.path.join(model_dir, f"norm_{variable}.json")
    if not os.path.exists(norm_path):
        raise FileNotFoundError(f"Missing norm file: {norm_path}")

    with open(norm_path, "r") as f:
        norm = json.load(f)

    if "type" not in norm:
        raise ValueError(f"Invalid norm file (missing 'type'): {norm_path}")

    print(f"[Eval] Loaded norm: {norm}")
    return model, norm


def apply_norm(X: torch.Tensor, norm: Dict) -> torch.Tensor:
    """Apply SAME normalization as in training."""
    norm_type = norm.get("type", "z")

    if norm_type == "log1p":
        return torch.log1p(X)

    if norm_type == "z":
        mean = float(norm["mean"])
        std = float(norm.get("std", 1e-6))
        return (X - mean) / (std + 1e-6)

    # Fallback: no normalization
    print(f"[WARN] Unknown norm type '{norm_type}', using raw values.")
    return X


def denorm_pred(pred: torch.Tensor, norm: Dict) -> torch.Tensor:
    """Convert model output back to ERA5 units."""
    norm_type = norm.get("type", "z")

    if norm_type == "log1p":
        # Model output is log1p(x)
        return torch.expm1(pred)

    if norm_type == "z":
        mean = float(norm["mean"])
        std = float(norm.get("std", 1e-6))
        return pred * (std + 1e-6) + mean

    return pred


def evaluate(
    variable: str,
    data_glob: str,
    model_dir: str,
    context_hours: int,
    forecast_hours: int,
    batch_size: int,
    max_batches: Optional[int] = None,
    device: Optional[torch.device] = None,
):
    device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Eval] Using device: {device}")

    # Find data files
    print("[Eval] Searching ERA5 files...")
    files = sorted(glob.glob(data_glob))
    if not files:
        raise RuntimeError(f"No files match: {data_glob}")
    print(f"[Eval] Found {len(files)} files")

    # Build dataset
    dataset = Era5ForecastDataset(
        files=files,
        variable=variable,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
    )

    # Load model + norm
    model, norm = load_model_and_norm(
        variable=variable,
        model_dir=model_dir,
        context_hours=context_hours,
        forecast_hours=forecast_hours,
        device=device,
    )

    # DataLoader
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=2,
        pin_memory=True,
        drop_last=False,
    )

    # Metrics accumulators
    sum_sq_error = 0.0
    sum_abs_error = 0.0
    sum_error = 0.0
    count = 0

    model.eval()
    with torch.no_grad():
        pbar = tqdm(loader, desc="[Eval] Batches")
        for bidx, (X, Y) in enumerate(pbar):
            if max_batches is not None and bidx >= max_batches:
                break

            # X, Y: [B, T, H, W]
            X = X.to(device, non_blocking=True)
            Y = Y.to(device, non_blocking=True)

            # Save Y in ERA5 units for metrics
            Y_true = Y.clone()

            # Normalize input
            X_norm = apply_norm(X, norm)

            # Model expects [B, C, H, W]; here C = context_hours
            pred_norm = model(X_norm)

            # Denormalize predictions to ERA5 units
            pred = denorm_pred(pred_norm, norm)

            # Clip to same shape
            if pred.shape != Y_true.shape:
                # crop/pad T, H, W if needed
                T = min(pred.shape[1], Y_true.shape[1])
                H = min(pred.shape[2], Y_true.shape[2])
                W = min(pred.shape[3], Y_true.shape[3])
                pred = pred[:, :T, :H, :W]
                Y_true = Y_true[:, :T, :H, :W]

            diff = pred - Y_true
            sum_sq_error += float(torch.sum(diff ** 2).item())
            sum_abs_error += float(torch.sum(torch.abs(diff)).item())
            sum_error += float(torch.sum(diff).item())
            count += diff.numel()

            if count > 0:
                rmse = (sum_sq_error / count) ** 0.5
                mae = sum_abs_error / count
                bias = sum_error / count
                pbar.set_postfix({"RMSE": f"{rmse:.4f}", "MAE": f"{mae:.4f}", "Bias": f"{bias:.4f}"})

    if count == 0:
        print("[Eval] No samples evaluated.")
        return

    rmse = (sum_sq_error / count) ** 0.5
    mae = sum_abs_error / count
    bias = sum_error / count

    print("====================================")
    print(f"[Eval] Variable:      {variable}")
    print(f"[Eval] Samples:       {count}")
    print(f"[Eval] Global RMSE:   {rmse:.6f}")
    print(f"[Eval] Global MAE:    {mae:.6f}")
    print(f"[Eval] Global Bias:   {bias:.6f}")
    print("====================================")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variable", required=True, help="e.g. 2m_temperature")
    ap.add_argument(
        "--data-glob",
        required=True,
        help="Pattern like 'era5_data/era5_*_2m_temperature.nc'",
    )
    ap.add_argument(
        "--model-dir",
        required=True,
        help="Directory with <variable>.pt and norm_<variable>.json",
    )
    ap.add_argument("--context-hours", type=int, default=24)
    ap.add_argument("--forecast-hours", type=int, default=24)
    ap.add_argument("--batch-size", type=int, default=2)
    ap.add_argument(
        "--max-batches",
        type=int,
        default=None,
        help="Limit number of batches for quick tests (optional)",
    )

    args = ap.parse_args()

    evaluate(
        variable=args.variable,
        data_glob=args.data_glob,
        model_dir=args.model_dir,
        context_hours=args.context_hours,
        forecast_hours=args.forecast_hours,
        batch_size=args.batch_size,
        max_batches=args.max_batches,
    )


if __name__ == "__main__":
    main()
