/*
 * SPDX-FileCopyrightText: 2025 Rayleigh Research <to@rayleigh.re>
 * SPDX-License-Identifier: MIT
 */
#pragma once

#include "CheckpointSerializable.hpp"
#include "mp.hpp"

#include <fmt/format.h>

#include <memory>
#include <mutex>
#include <span>
#include <unordered_set>
#include <vector>

//-------------------------------------------------------------------------

template<typename T>
requires (!taosim::mp::IsPointer<T>)
class SubscriptionRegistry : public CheckpointSerializable
{
public:
    SubscriptionRegistry() noexcept : m_mtx{std::make_unique<std::mutex>()} {}

    [[nodiscard]] std::span<const T> subs() const noexcept
    {
        std::scoped_lock lock{*m_mtx};
        return m_subs;
    }

    bool add(const T& sub) noexcept
    {
        std::scoped_lock lock{*m_mtx};
        if (m_registry.contains(sub)) {
            return false;
        }
        m_subs.push_back(sub);
        m_registry.insert(sub);
        return true;
    }

    auto begin() const noexcept { return m_subs.begin(); }
    auto end() const noexcept { return m_subs.end(); }

    virtual void checkpointSerialize(
        rapidjson::Document& json, const std::string& key = {}) const override
    {
        auto serialize = [this](rapidjson::Document& json) {
            json.SetArray();
            auto& allocator = json.GetAllocator();
            for (const T& sub : *this) {
                if constexpr (requires(T t) { t.checkpointSerialize(json); }) {
                    rapidjson::Document subJson{&allocator};
                    sub.checkpointSerialize(subJson);
                    json.PushBack(subJson, allocator);
                } else if constexpr (requires(T t) { t.c_str(); }) {
                    json.PushBack(rapidjson::Value{sub.c_str(), allocator}, allocator);
                } else if constexpr (requires(T t) { json.PushBack(t, allocator); }) {
                    json.PushBack(sub, allocator);
                } else {
                    static_assert(false);
                }
            }
        };
        taosim::json::serializeHelper(json, key, serialize);
    }

    [[nodiscard]] static SubscriptionRegistry<T> fromJson(const rapidjson::Value& json)
    {
        SubscriptionRegistry reg;
        for (const rapidjson::Value& subJson : json.GetArray()) {
            if constexpr (std::signed_integral<T>) {
                reg.add(subJson.GetInt());
            } else if constexpr (std::unsigned_integral<T>) {
                reg.add(subJson.GetUint());
            } else if constexpr (std::convertible_to<const char*, T>) {
                reg.add(subJson.GetString());
            } else {
                static_assert(false);
            }
        }
        return reg;
    }

private:
    std::unique_ptr<std::mutex> m_mtx;
    std::vector<T> m_subs;
    std::unordered_set<T> m_registry;
};

//-------------------------------------------------------------------------
